package ses4;

public class Application {

	private static Product[] products1;
	private static Product[] products2;
	public static void main(String[] args) throws Exception {
		System.out.println("PRODUCTS 1");
		products1 = Shelves.readFromFiles("files/productos1.txt");
		System.out.println("Unordered shelves: "+Shelves.calculateAverageAccesTime(products1));
		products1 = Shelves.readFromFiles("files/productos1.txt");
		Shelves.orderByHeuristic(products1);
		System.out.println("Heuristicly sorted shelves: "+Shelves.calculateAverageAccesTime(products1));
		products1 = Shelves.readFromFiles("files/productos1.txt");
		Shelves.orderByLength(products1);
		System.out.println("Lengthly sorted shelves: "+Shelves.calculateAverageAccesTime(products1));
		products1 = Shelves.readFromFiles("files/productos1.txt");
		Shelves.orderByRequest(products1);
		System.out.println("Requestly sorted shelves: "+Shelves.calculateAverageAccesTime(products1));  
		System.out.println();
		
		System.out.println("PRODUCTS 2");
		products2 = Shelves.readFromFiles("files/productos2.txt");
		System.out.println("Unordered shelves: "+Shelves.calculateAverageAccesTime(products2));
		products2 = Shelves.readFromFiles("files/productos2.txt");
		Shelves.orderByHeuristic(products2);
		System.out.println("Heuristicly sorted shelves: "+Shelves.calculateAverageAccesTime(products2));
		products2 = Shelves.readFromFiles("files/productos2.txt");
		Shelves.orderByLength(products2);
		System.out.println("Lengthly sorted shelves: "+Shelves.calculateAverageAccesTime(products2));
		products2 = Shelves.readFromFiles("files/productos2.txt");
		Shelves.orderByRequest(products2);
		System.out.println("Requestly sorted shelves: "+Shelves.calculateAverageAccesTime(products2));
	}
}
